# Access Web
A collection of useful, reusable, non-project specific utilities, tools, etc in the web domain

### What is this repository for? ###

* Chrome extensions
* Javascript generators
* Web-centric linters and build tools

### Contribution guidelines ###

* Usual standard of 80% test coverage
* High-quality reviews
* Useful stuff

### Who do I talk to? ###

* Glen Edmonds @gedmonds (repo owner)
* Ash Newport @anewport
