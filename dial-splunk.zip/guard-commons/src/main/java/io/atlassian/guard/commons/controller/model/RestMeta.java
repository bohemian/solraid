package io.atlassian.guard.commons.controller.model;

import java.util.HashMap;

public class RestMeta extends HashMap<String, String> {
}
