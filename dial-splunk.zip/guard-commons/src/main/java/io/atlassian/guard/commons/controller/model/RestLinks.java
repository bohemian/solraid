package io.atlassian.guard.commons.controller.model;

public record RestLinks(String self, String prev, String next) {
}
